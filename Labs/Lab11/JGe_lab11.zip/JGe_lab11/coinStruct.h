#ifndef _COINSTRUCT
#define _COINSTRUCT

#include "stdafx.h"
#include <iostream>
     
using namespace std;

class coinStruct
{
public:
	int totalNbCoins;
	int* nbEachCoin;

	coinStruct();
};

#endif